<?php
$host="localhost";
$user="root";
$password="";
$db="carrentalsystem";

$con=mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);

/*Search Part for Customer*/
if($_POST['search'] == 'search'){
    if(!empty($_POST['customerFirstName']) or !empty($_POST['customerLastName']) or !empty($_POST['customerSSN']) or !empty($_POST['customerCity']) ){
        $whereClause="where "; /**we will concatenate on this clause with each attribute inserted**/
        if(!empty($_POST['customerFirstName'])){
            $customerFirstName=$_POST['customerFirstName'];
            $words = explode(",", $customerFirstName); /**split input in text field into array of substrings**/
            $whereClause.="(";
            foreach ($words as $word) {
                $whereClause .="cr.first_name="."'$word'"." OR "; /**loop over each substring and add it to where clause
                                                        e.x: model=corsa OR model=astra OR..**/
            }
            $whereClause=substr($whereClause,0,-3); /**remove extra OR at end**/
            $whereClause.=") AND "; /**add AND for next attribute e.x: model=astra AND year=...**/
        }
        if(!empty($_POST['customerLastName'])){
            $customerLastName=$_POST['customerLastName'];
            $words = explode(",", $customerLastName);
            $whereClause.="(";
            foreach ($words as $word) {
                $whereClause .="cr.last_name="."'$word'"." OR ";
            }
            $whereClause=substr($whereClause,0,-3);
            $whereClause.=") AND ";
        }
        if(!empty($_POST['customerSSN'])){
            $customerSSN=$_POST['customerSSN'];
            $ints = array_map("intval",explode(",", $customerSSN));
            $whereClause.="(";
            foreach ($ints as $int1) {
                $whereClause .="cr.ssn="."$int1"." OR ";
            }
            $whereClause=substr($whereClause,0,-3);
            $whereClause.=") AND ";
        }
        if(!empty($_POST['customerCity'])){
            $customerCity=$_POST['customerCity'];
            $words = explode(",", $customerCity);
            $whereClause.="(";
            foreach ($words as $word) {
                $whereClause .="cr.city="."'$word'"." OR ";
            }
            $whereClause=substr($whereClause,0,-3);
            $whereClause.=") AND ";
        }
        $whereClause=substr($whereClause,0,-4);
        $sql1="SELECT * FROM customer cr ".$whereClause;
        echo $sql1;
        $result=mysqli_query($con,$sql1);
        if (mysqli_num_rows($result) > 0) {
          echo "<table border=\"2\"><tr><th>Customer ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
          <th>License Number</th><th>DOB</th><th>SSN</th><th>City</th></tr>";
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr class='clickable' onclick=\"window.location='search.html'\">
            <td>".$row["customer_id"]."</td>
            <td>".$row["first_name"]."</td><td>".$row["mid_name"]."</td><td>".$row["last_name"]."</td>
            <td>".$row["lisence_no"]."</td><td>".$row["DOB"]."</td>
            <td>".$row["ssn"]."</td><td>".$row["city"]."</td></tr>";
          }
          echo "</table><br>";
        } else {
          echo "0 results";
        }
    }
}
    
    if($_POST['search'] == 'customers-search'){
        $sql1="SELECT * FROM customer cr ";
        echo $sql1;
        $result=mysqli_query($con,$sql1);
        if (mysqli_num_rows($result) > 0) {
          echo "<table border=\"2\"><tr><th>Customer ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
          <th>License Number</th><th>DOB</th><th>SSN</th><th>City</th></tr>";
          // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tr class='clickable' onclick=\"window.location='search.html'\">
            <td>".$row["customer_id"]."</td>
            <td>".$row["first_name"]."</td><td>".$row["mid_name"]."</td><td>".$row["last_name"]."</td>
            <td>".$row["lisence_no"]."</td><td>".$row["DOB"]."</td>
            <td>".$row["ssn"]."</td><td>".$row["city"]."</td></tr>";
          }
          echo "</table><br>";
        } else {
          echo "0 results";
        }
    }

    /**Part of search for cars table**/
    if($_POST['search'] == 'search'){
        if(!empty($_POST['carModel']) or !empty($_POST['carYear']) or !empty($_POST['carPlate']) or !empty($_POST['carColor']) ){
            $whereClause="where "; /**we will concatenate on this clause with each attribute inserted**/
            if(!empty($_POST['carModel'])){
                $carModel=$_POST['carModel'];
                $words = explode(",", $carModel); /**split input in text field into array of substrings**/
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.model="."'$word'"." OR "; /**loop over each substring and add it to where clause
                                                            e.x: model=corsa OR model=astra OR..**/
                }
                $whereClause=substr($whereClause,0,-3); /**remove extra OR at end**/
                $whereClause.=") AND "; /**add AND for next attribute e.x: model=astra AND year=...**/
            }
            if(!empty($_POST['carYear'])){
                $carYear=$_POST['carYear'];
                $ints = array_map("intval",explode(",", $carYear));
                $whereClause.="(";
                foreach ($ints as $int1) {
                    $whereClause .="c.year="."$int1"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carPlate'])){
                $carPlate=$_POST['carPlate'];
                $words = explode(",", $carPlate);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.plate_id="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carColor'])){
                $carColor=$_POST['carColor'];
                $words = explode(",", $carColor);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.color="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carMode'])){
                $carMode=$_POST['carMode'];
                $words = explode(",", $carMode);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.mode="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            $whereClause=substr($whereClause,0,-4);
            $sql="SELECT * FROM car c ".$whereClause;
            echo $sql;
            $result=mysqli_query($con,$sql);
            if (mysqli_num_rows($result) > 0) {
              echo "<table border=\"1\"><tr><th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th><th>Mode</th><th>Status</th></tr>";
              // output data of each row
              while($row = $result->fetch_assoc()) {
                echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                <td>".$row["car_id"]."</td><td>".$row["model"]."</td>
                <td>".$row["year"]."</td><td>".$row["plate_id"]."</td>
                <td>".$row["color"]."</td><td>".$row["no_of_seats"]."</td>
                <td>".$row["mode"]."</td><td>".$row["status"]."</tr>";
              }
              echo "</table>";
            } else {
              echo "0 results";
            }
        }
    }
    
    if($_POST['search'] == 'cars-search'){
        $sql="SELECT * FROM car c ";
        echo $sql;
        $result=mysqli_query($con,$sql);
        if (mysqli_num_rows($result) > 0) {
            echo "<table border=\"1\"><tr><th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th><th>Mode</th><th>Status</th></tr>";
            // output data of each row
            while($row = $result->fetch_assoc()) {
            echo "<tr class='clickable' onclick=\"window.location='search.html'\">
            <td>".$row["car_id"]."</td><td>".$row["model"]."</td>
            <td>".$row["year"]."</td><td>".$row["plate_id"]."</td>
            <td>".$row["color"]."</td><td>".$row["no_of_seats"]."</td>
            <td>".$row["mode"]."</td><td>".$row["status"]."</tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
    }

    if($_POST['search'] == 'reservations-search' or $_POST['search'] == 'search'){
        /*Retrieving all reservations*/
        if(empty($_POST['reservationDate']) and empty($_POST['returnDate']) and $_POST['search'] == 'reservations-search'){
            $sql2="SELECT * FROM reservation r";
            echo $sql2;
            $result=mysqli_query($con,$sql2);
            if (mysqli_num_rows($result) > 0) {
              echo "<table border=\"2\"><tr><th>Reserve No</th><th>Car ID</th><th>Customer ID</th><th>Pick-Up Date</th><th>Return Date</th><th>Branch ID</th></tr>";
              // output data of each row
              while($row = $result->fetch_assoc()) {
                echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                <td>".$row["reserve_no"]."</td><td>".$row["car_id"]."</td>
                <td>".$row["customer_id"]."</td><td>".$row["pickup_date"]."</td>
                <td>".$row["return_date"]."</td><td>".$row["branch_id"]."</tr>";
              }
              echo "</table>";
            } else {
              echo "0 results";
            }
        }
        /*Search By Reservation Day*/
        if(!empty($_POST['reservationDate']) and empty($_POST['returnDate'])){
            $reservationDate = date('Y-m-d', strtotime($_POST['reservationDate']));
            $sql2="SELECT * FROM reservation r WHERE r.pickup_date= "."'$reservationDate'";
            echo $sql2;
            $result=mysqli_query($con,$sql2);
            if (mysqli_num_rows($result) > 0) {
              echo "<table border=\"2\"><tr><th>Reserve No</th><th>Car ID</th><th>Customer ID</th><th>Pick-Up Date</th><th>Return Date</th><th>Branch ID</th></tr>";
              // output data of each row
              while($row = $result->fetch_assoc()) {
                echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                <td>".$row["reserve_no"]."</td><td>".$row["car_id"]."</td>
                <td>".$row["customer_id"]."</td><td>".$row["pickup_date"]."</td>
                <td>".$row["return_date"]."</td><td>".$row["branch_id"]."</tr>";
              }
              echo "</table>";
            } else {
              echo "0 results";
            }
        }
        
        /*Search For Reservations Within Specified Period*/
        
        if(!empty($_POST['reservationDate']) and !empty($_POST['returnDate']) ){
            $reservationDate = date('Y-m-d', strtotime($_POST['reservationDate']));
            $returnDate = date('Y-m-d', strtotime($_POST['returnDate']));
            $sql3="SELECT * FROM reservation r, customer cr, car c WHERE r.pickup_date>="."'$reservationDate' AND r.pickup_date<="."'$returnDate' 
            AND r.customer_id=cr.customer_id AND r.car_id=c.car_id";
            echo $sql3;
            $result=mysqli_query($con,$sql3);
            if (mysqli_num_rows($result) > 0) {
                echo "<table border=\"1\"><tr><th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th><th>Mode</th><th>Status</th>
                <th>Customer ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
                <th>License Number</th><th>DOB</th><th>SSN</th><th>City</th></tr>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                  echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                  <td>".$row["car_id"]."</td><td>".$row["model"]."</td>
                  <td>".$row["year"]."</td><td>".$row["plate_id"]."</td>
                  <td>".$row["color"]."</td><td>".$row["no_of_seats"]."</td>
                  <td>".$row["mode"]."</td><td>".$row["status"]."</td><td>".$row["customer_id"]."</td>
                  <td>".$row["first_name"]."</td><td>".$row["mid_name"]."</td><td>".$row["last_name"]."</td>
                  <td>".$row["lisence_no"]."</td><td>".$row["DOB"]."</td>
                  <td>".$row["ssn"]."</td><td>".$row["city"]."</td></tr>";
                }
                echo "</table>";
              } else {
                echo "0 results";
              }
        }

        /*Search For Reservations Per Car Within Specified Period*/

        if(!empty($_POST['reservationDate']) and !empty($_POST['returnDate']) and !empty($_POST['carModel']) ){
            $reservationDate = date('Y-m-d', strtotime($_POST['reservationDate']));
            $returnDate = date('Y-m-d', strtotime($_POST['returnDate']));
            $carModel=$_POST['carModel'];
            $sql6="SELECT * FROM reservation r,car c WHERE r.pickup_date>="."'$reservationDate' AND r.pickup_date<="."'$returnDate' 
            AND c.model="."'$carModel'"." AND r.car_id=c.car_id";
            echo $sql6;
            $result=mysqli_query($con,$sql6);
            if (mysqli_num_rows($result) > 0) {
                echo "<table border=\"1\"><tr><th>Reservation Number</th><th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th><th>Mode</th><th>Status</th>
                <th>Reservation Day</th><th>Return Day</th></tr>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                echo "<tr class='clickable' onclick=\"window.location='search.html'\"><td>".$row["reserve_no"]."</td>
                <td>".$row["car_id"]."</td><td>".$row["model"]."</td>
                <td>".$row["year"]."</td><td>".$row["plate_id"]."</td>
                <td>".$row["color"]."</td><td>".$row["no_of_seats"]."</td>
                <td>".$row["mode"]."</td><td>".$row["status"]."</td>
                <td>".$row["pickup_date"]."</td><td>".$row["return_date"]."</td></tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
        }
    }
    
    /*Advanced Search*/
    if($_POST['search'] == 'advanced-search'){
            $whereClause="where "; /**we will concatenate on this clause with each attribute inserted**/
            if(!empty($_POST['customerFirstName'])){
                $customerFirstName=$_POST['customerFirstName'];
                $words = explode(",", $customerFirstName); /**split input in text field into array of substrings**/
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="cr.first_name="."'$word'"." OR "; /**loop over each substring and add it to where clause
                                                            e.x: model=corsa OR model=astra OR..**/
                }
                $whereClause=substr($whereClause,0,-3); /**remove extra OR at end**/
                $whereClause.=") AND "; /**add AND for next attribute e.x: model=astra AND year=...**/
            }
            if(!empty($_POST['customerLastName'])){
                $customerLastName=$_POST['customerLastName'];
                $words = explode(",", $customerLastName);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="cr.last_name="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['customerSSN'])){
                $customerSSN=$_POST['customerSSN'];
                $ints = array_map("intval",explode(",", $customerSSN));
                $whereClause.="(";
                foreach ($ints as $int1) {
                    $whereClause .="cr.ssn="."$int1"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['customerCity'])){
                $customerCity=$_POST['customerCity'];
                $words = explode(",", $customerCity);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="cr.city="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carModel'])){
                $carModel=$_POST['carModel'];
                $words = explode(",", $carModel); /**split input in text field into array of substrings**/
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.model="."'$word'"." OR "; /**loop over each substring and add it to where clause
                                                            e.x: model=corsa OR model=astra OR..**/
                }
                $whereClause=substr($whereClause,0,-3); /**remove extra OR at end**/
                $whereClause.=") AND "; /**add AND for next attribute e.x: model=astra AND year=...**/
            }
            if(!empty($_POST['carYear'])){
                $carYear=$_POST['carYear'];
                $ints = array_map("intval",explode(",", $carYear));
                $whereClause.="(";
                foreach ($ints as $int1) {
                    $whereClause .="c.year="."$int1"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carPlate'])){
                $carPlate=$_POST['carPlate'];
                $words = explode(",", $carPlate);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.plate_id="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carColor'])){
                $carColor=$_POST['carColor'];
                $words = explode(",", $carColor);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.color="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['carMode'])){
                $carMode=$_POST['carMode'];
                $words = explode(",", $carMode);
                $whereClause.="(";
                foreach ($words as $word) {
                    $whereClause .="c.mode="."'$word'"." OR ";
                }
                $whereClause=substr($whereClause,0,-3);
                $whereClause.=") AND ";
            }
            if(!empty($_POST['reservationDate']) ){
                $reservationDate = date('Y-m-d', strtotime($_POST['reservationDate']));
                $whereClause.="(r.pickup_date= "."'$reservationDate'";
                $whereClause.=") AND ";
        
            }
            $whereClause=substr($whereClause,0,-4);
            $sql5="SELECT * FROM reservation r,customer cr,car c ".$whereClause." 
            AND r.car_id=c.car_id AND cr.customer_id=r.customer_id";
            echo $sql5;
            $result=mysqli_query($con,$sql5);
            if (mysqli_num_rows($result) > 0) {
              echo "<table border=\"2\"><tr><th>Customer ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
              <th>License Number</th><th>DOB</th><th>SSN</th><th>City</th>
              <th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th>
              <th>Mode</th><th>Status</th><th>Reserve No</th><th>Pick-Up Date</th><th>Return Date</th><th>Branch ID</th></tr>";
              // output data of each row
              while($row = $result->fetch_assoc()) {
                echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                <td>".$row["customer_id"]."</td>
                <td>".$row["first_name"]."</td><td>".$row["mid_name"]."</td><td>".$row["last_name"]."</td>
                <td>".$row["lisence_no"]."</td><td>".$row["DOB"]."</td>
                <td>".$row["ssn"]."</td><td>".$row["city"]."</td>
                <td>".$row["car_id"]."</td><td>".$row["model"]."</td>
                <td>".$row["year"]."</td><td>".$row["plate_id"]."</td>
                <td>".$row["color"]."</td><td>".$row["no_of_seats"]."</td>
                <td>".$row["mode"]."</td><td>".$row["status"]."</td>
                <td>".$row["reserve_no"]."</td><td>".$row["pickup_date"]."</td>
                <td>".$row["return_date"]."</td><td>".$row["branch_id"]."</tr>";
              }
              echo "</table><br>";
            } else {
              echo "0 results";
            }
    }
    
    // the state of all cars on a specific day
    if($_POST['search'] == 'state-search'){
        if(!empty($_POST['requiredDate'])){
            $requiredDate = date('Y-m-d', strtotime($_POST['requiredDate']));
            $firstSQL = "SELECT c.* FROM `car` c INNER JOIN `reservation` r ON c.car_id = r.car_id WHERE "."'$requiredDate' BETWEEN r.pickup_date AND r.return_date";
            $secondSQL = "SELECT c.* FROM `car` c LEFT OUTER JOIN `reservation` r ON c.car_id = r.car_id WHERE c.car_id NOT IN (SELECT c1.car_id FROM `car` c1 INNER JOIN `reservation` r ON c1.car_id = r.car_id WHERE "."'$requiredDate' BETWEEN r.pickup_date AND r.return_date)";
            echo $firstSQL;
            echo $secondSQL;
            $firstresult = mysqli_query($con,$firstSQL);
            $secondresult = mysqli_query($con,$secondSQL);
            if (mysqli_num_rows($firstresult) > 0 or mysqli_num_rows($secondresult) > 0) {
                echo "<table border=\"1\"><tr><th>Car Id</th><th>Model</th><th>Year</th><th>Plate Id</th><th>Color</th><th>Seats</th><th>Mode</th><th>Status</th><th>State</th></tr>";
                // output data of each row from first result
                if (mysqli_num_rows($firstresult) > 0){
                    while($rowset1 = $firstresult->fetch_assoc()) {
                        echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                        <td>".$rowset1["car_id"]."</td><td>".$rowset1["model"]."</td>
                        <td>".$rowset1["year"]."</td><td>".$rowset1["plate_id"]."</td>
                        <td>".$rowset1["color"]."</td><td>".$rowset1["no_of_seats"]."</td>
                        <td>".$rowset1["mode"]."</td><td>".$rowset1["status"]."</td><td>reserved</td></tr>";
                    }
                }
                // output data of each row from second result
                if (mysqli_num_rows($secondresult) > 0){
                    while($rowset2 = $secondresult->fetch_assoc()) {
                        echo "<tr class='clickable' onclick=\"window.location='search.html'\">
                        <td>".$rowset2["car_id"]."</td><td>".$rowset2["model"]."</td>
                        <td>".$rowset2["year"]."</td><td>".$rowset2["plate_id"]."</td>
                        <td>".$rowset2["color"]."</td><td>".$rowset2["no_of_seats"]."</td>
                        <td>".$rowset2["mode"]."</td><td>".$rowset2["status"]."</td><td>not reserved</td></tr>";
                    }
                }
                echo "</table>";
            } else {
                echo "0 results";
              }
        }
    }


    /*Reservations Per Customer Within Specific Period*/
    if($_POST['search'] == 'customers-reservations-search'){
        $customerFirstName=$_POST['customerFirstName'];
        $reservationDate = date('Y-m-d', strtotime($_POST['reservationDate']));
        $returnDate = date('Y-m-d', strtotime($_POST['returnDate']));
        $sql3="SELECT * FROM reservation r, customer cr, car c, payment p WHERE cr.first_name="."'$customerFirstName' 
        AND r.pickup_date>="."'$reservationDate' AND r.pickup_date<="."'$returnDate'"." AND r.customer_id=cr.customer_id AND r.car_id=c.car_id AND p.reserve_no=r.reserve_no";
        echo $sql3;
        $result=mysqli_query($con,$sql3);
        if (mysqli_num_rows($result) > 0) {
            echo "<table border=\"1\"><tr><th>Customer ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
            <th>License Number</th><th>SSN</th><th>City</th><th>Model</th><th>Plate ID</th><th>Payment Amount</th></tr>";
            // output data of each row
            while($row = $result->fetch_assoc()) {
            echo "<tr class='clickable' onclick=\"window.location='search.html'\">
            <td>".$row["customer_id"]."</td>
            <td>".$row["first_name"]."</td><td>".$row["mid_name"]."</td><td>".$row["last_name"]."</td>
            <td>".$row["lisence_no"]."</td>
            <td>".$row["ssn"]."</td><td>".$row["city"]."</td>
            <td>".$row["model"]."</td><td>".$row["plate_id"]."</td><td>".$row["total_amount"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
    }
    /*Update Status Of Car*/
    if($_POST['search'] == 'update'){
        $carId=$_POST["carID"];
        $carNewState=$_POST["newStatus"];
        $sql="UPDATE car c SET c.status="."'$carNewState'"." WHERE c.car_id="."'$carId'";
        if(mysqli_query($con,$sql)){
            echo "<script>alert('Car Updated Successfully');
            window.location.href='search.html';
            </script>";
            exit();
        }
        else{
            echo '<script>alert("Invalid Inputs!")
            </script>';
            exit();
        }

    }
?>