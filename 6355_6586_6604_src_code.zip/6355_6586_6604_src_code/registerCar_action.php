<?php
$host="localhost";
$user="root";
$password="";
$db="carrentalsystem";

$con=mysqli_connect($host,$user,$password);
mysqli_select_db($con,$db);
if(isset($_POST['newCarModel'])){
    $newCarModel=$_POST['newCarModel'];
    $newCarYear=$_POST['newCarYear'];
    $newCarPlate=$_POST['newCarPlate'];
    $newCarColor=$_POST['newCarColor'];
    $newCarSeats=$_POST['newCarSeats'];
    $newCarMode=$_POST['newCarMode'];
    $newCarStatus=$_POST['newCarStatus'];
    $sql="insert into car (model,year,plate_id,color,no_of_seats,mode,status) VALUES('$newCarModel','$newCarYear','$newCarPlate','$newCarColor','$newCarSeats','$newCarMode','$newCarStatus')";
    if(mysqli_query($con,$sql)){
        echo "<script>alert('Car Registered Successfully');
        window.location.href='search.html';
        </script>";
        exit();
    }
    else{
        echo '<script>alert("Invalid Inputs!")
        </script>';
        exit();
    }
}
?>